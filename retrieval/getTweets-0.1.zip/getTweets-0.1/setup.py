
from setuptools import setup

setup(
	name='getTweets',
	version='0.1',
	description='Use of Twitter api',
	author='me',
	packages=['getTweets']
)